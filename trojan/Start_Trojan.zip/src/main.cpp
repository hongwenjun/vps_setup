#include <windows.h>

void kill_trojan(void)
{
    char cmdline[] = "taskkill.exe /f /im trojan.exe ";
    WinExec(cmdline, SW_HIDE);
}

int main(int argc, char* argv[])
{

    int result = MessageBox(NULL, TEXT("请选择启动 Trojan服务(是)\n或者关闭 Trojan服务(否)!"),
                            TEXT("简易 Trojan 启动器!"), MB_ICONINFORMATION | MB_YESNO);


    if (result == 6) {
        WinExec("trojan.exe", SW_HIDE);
    } else if (result == 7) {
        kill_trojan();
    }

//   WinExec("kcptun-clt.exe -r \"remote_ip:port\" -l \":port\" -mode fast2", SW_HIDE);

    return result;
}
